package com.amazecare.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.amazecare.model.Consultation;
import com.amazecare.repository.ConsultationRepository;

@RestController
@RequestMapping("/api/consultations")
public class ConsultationController {

    @Autowired
    private ConsultationRepository consultationRepository;

    // CREATE
    @PostMapping
    public Consultation addConsultation(@RequestBody Consultation consultation) {
        return consultationRepository.save(consultation);
    }

    // READ ALL
    @GetMapping
    public List<Consultation> getAllConsultations() {
        return consultationRepository.findAll();
    }

    // READ by appointment ID
    @GetMapping("/appointment/{id}")
    public ResponseEntity<Consultation> getByAppointmentId(@PathVariable Long id) {
        return consultationRepository.findByAppointmentId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // READ by consultation ID
    @GetMapping("/{id}")
    public ResponseEntity<Consultation> getById(@PathVariable Long id) {
        Optional<Consultation> consultation = consultationRepository.findById(id);
        return consultation.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<Consultation> updateConsultation(@PathVariable Long id, @RequestBody Consultation updated) {
        Consultation consultation = consultationRepository.findById(id).orElseThrow();

        consultation.setSymptoms(updated.getSymptoms());
        consultation.setPhysicalExam(updated.getPhysicalExam());
        consultation.setTreatmentPlan(updated.getTreatmentPlan());
        consultation.setRecommendedTests(updated.getRecommendedTests());
        consultation.setPrescription(updated.getPrescription());

        return ResponseEntity.ok(consultationRepository.save(consultation));
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteConsultation(@PathVariable Long id) {
        Consultation consultation = consultationRepository.findById(id).orElseThrow();
        consultationRepository.delete(consultation);
        return ResponseEntity.ok("Consultation deleted successfully.");
    }
}
