package com.amazecare.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class RegisterRequest {

    // Common fields
    @NotBlank
    private String username;

    @NotBlank
    private String password;

    @Email
    private String email;

    @NotNull
    private String role;

    // PATIENT fields
    @NotBlank
    private String fullName;
    private String gender; // MALE, FEMALE, OTHER
    private LocalDate dob;
    private String contactNumber;
    private String medicalHistory;

    // DOCTOR fields
    private String specialty;
    private Integer experience;
    private String qualification;
    private String designation;
    private Long hospitalId;

    // EMPLOYEE fields
    private String department;
}
