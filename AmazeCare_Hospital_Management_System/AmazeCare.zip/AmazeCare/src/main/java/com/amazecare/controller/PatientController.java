package com.amazecare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazecare.model.Patient;
import com.amazecare.model.User;
import com.amazecare.repository.PatientRepository;
import com.amazecare.repository.UserRepository;

@RestController 
@RequestMapping ("/api/patients")
public class PatientController {

    @Autowired private PatientRepository patientRepository;
    @Autowired private UserRepository userRepository;


    @PostMapping 
    public Patient addPatient(@RequestBody Patient patient) {
        return patientRepository.save(patient);
    }

    @PutMapping ("/{id}")
    public ResponseEntity<Patient> updatePatient(@PathVariable Long id, @RequestBody Patient updated) {
        Patient patient = patientRepository.findById(id).orElseThrow();
        patient.setFullName(updated.getFullName());
        patient.setDob(updated.getDob());
        patient.setGender(updated.getGender());
        patient.setContactNumber(updated.getContactNumber());
        patient.setMedicalHistory(updated.getMedicalHistory());
        return ResponseEntity.ok(patientRepository.save(patient));
    }
    
    @GetMapping
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @GetMapping("/search")
    public List<Patient> searchByName(@RequestParam String name) {
        return patientRepository.findByFullNameContainingIgnoreCase(name);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Long id) {
        return patientRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePatient(@PathVariable Long id) {
        Patient patient = patientRepository.findById(id).orElseThrow();
        User user = patient.getUser();

        patientRepository.delete(patient);
        userRepository.delete(user);

        return ResponseEntity.ok("Patient and user deleted successfully.");
    }

}
