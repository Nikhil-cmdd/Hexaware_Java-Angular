package com.amazecare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazecare.model.Doctor;
import com.amazecare.model.User;
import com.amazecare.repository.DoctorRepository;
import com.amazecare.repository.UserRepository;

@RestController 
@RequestMapping ("/api/doctors")
public class DoctorController {

    @Autowired private DoctorRepository doctorRepository;
    @Autowired private UserRepository userRepository;


    @PostMapping 
    public Doctor addDoctor(@RequestBody Doctor doctor) {
        if (doctor.getId() != null) {
            throw new IllegalArgumentException("New doctor should not have an ID");
        }
        return doctorRepository.save(doctor);
    }

    @GetMapping 
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    @GetMapping("/category")
    public List<Doctor> getBySpecialty(@RequestParam String specialty) {
        return doctorRepository.findBySpecialtyIgnoreCase(specialty);
    }

    @GetMapping("/search")
    public List<Doctor> searchByName(@RequestParam String name) {
        return doctorRepository.findByFullNameContainingIgnoreCase(name);
    }
    
    @PutMapping ("/{id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable Long id, @RequestBody Doctor updated) {
        Doctor doctor = doctorRepository.findById(id).orElseThrow();
        doctor.setFullName(updated.getFullName());
        doctor.setDesignation(updated.getDesignation());
        doctor.setExperience(updated.getExperience());
        doctor.setQualification(updated.getQualification());
        doctor.setSpecialty(updated.getSpecialty());
        return ResponseEntity.ok(doctorRepository.save(doctor));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDoctor(@PathVariable Long id) {
        Doctor doctor = doctorRepository.findById(id).orElseThrow();
        User user = doctor.getUser();
        doctorRepository.delete(doctor);
        userRepository.delete(user);
        return ResponseEntity.ok("Doctor and user deleted successfully.");
    }


}
