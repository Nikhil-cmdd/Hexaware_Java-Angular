package com.amazecare.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazecare.model.Consultation;
import com.amazecare.repository.ConsultationRepository;

@Service
public class ConsultationService {
    @Autowired private ConsultationRepository consultationRepository;

    public Consultation create(Consultation consultation) {
        return consultationRepository.save(consultation);
    }

    public Optional<Consultation> getByAppointmentId(Long appointmentId) {
        return consultationRepository.findByAppointmentId(appointmentId);
    }
}
