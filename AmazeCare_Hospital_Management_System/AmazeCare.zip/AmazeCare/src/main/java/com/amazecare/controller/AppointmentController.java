package com.amazecare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import com.amazecare.model.Appointment;
import com.amazecare.repository.AppointmentRepository;

@RestController 
@RequestMapping ("/api/appointments")
public class AppointmentController {

    @Autowired private AppointmentRepository appointmentRepository;

    @PostMapping  
    public Appointment bookAppointment(@RequestBody Appointment appointment) {
        appointment.setStatus(Appointment.Status.PENDING);
        return appointmentRepository.save(appointment);
    }

    @GetMapping 
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    @GetMapping ("/doctor/{id}")
    public List<Appointment> getByDoctor(@PathVariable Long id) {
        return appointmentRepository.findByDoctorId(id);
    }

    @GetMapping("/patient/{id}")
    public List<Appointment> getByPatient(@PathVariable Long id) {
        return appointmentRepository.findByPatientId(id);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Appointment> updateStatus(@PathVariable Long id, @RequestParam Appointment.Status status) {
        Appointment appt = appointmentRepository.findById(id).orElseThrow();
        appt.setStatus(status);
        return ResponseEntity.ok(appointmentRepository.save(appt));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable Long id) {
        appointmentRepository.deleteById(id);
        return ResponseEntity.ok("Appointment deleted successfully.");
    }

}
