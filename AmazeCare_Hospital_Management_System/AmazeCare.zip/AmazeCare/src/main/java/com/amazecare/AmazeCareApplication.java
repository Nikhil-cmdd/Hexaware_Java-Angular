package com.amazecare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazeCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazeCareApplication.class, args);
	}

}
