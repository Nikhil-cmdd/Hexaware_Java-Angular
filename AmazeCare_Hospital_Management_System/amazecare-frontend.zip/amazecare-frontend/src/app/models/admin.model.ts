export interface Admin {
  id?: number;
  fullName: string;
  email: string;
  password?: string; // optional when editing
}
