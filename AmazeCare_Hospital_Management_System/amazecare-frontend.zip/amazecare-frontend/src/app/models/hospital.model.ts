export interface Hospital {
  id: number;
  name: string;
  location: string;
  contactNumber: string;
}
