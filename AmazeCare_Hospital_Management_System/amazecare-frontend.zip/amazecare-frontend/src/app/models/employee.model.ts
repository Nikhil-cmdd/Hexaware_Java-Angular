export interface Employee {
  id: number;
  fullName: string;
  department: string;
  contactNumber: string;
  email: string;
  gender: string;
  designation: string;
}
