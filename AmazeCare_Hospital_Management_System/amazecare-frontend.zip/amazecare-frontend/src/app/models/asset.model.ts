export interface Asset {
  id?: number;
  name: string;
  category?: string;
  quantity: number;
}
